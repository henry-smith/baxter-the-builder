#!/usr/bin/env python
"""
Starter script for EE106B grasp planning lab
Author: Jeff Mahler
"""
import warnings
warnings.filterwarnings("ignore") 
import numpy as np

from core import RigidTransform, Point
from meshpy import ObjFile
from visualization import Visualizer3D as vis

import rospy
import moveit_commander
from moveit_msgs.msg import MoveGroupAction, MoveGroupGoal, MoveGroupFeedback, MoveGroupResult, JointConstraint, OrientationConstraint, Constraints
from geometry_msgs.msg import PoseStamped, Pose
from baxter_interface import gripper as baxter_gripper
import actionlib

import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning) 

SPRAY_BOTTLE_MESH_FILENAME = '/home/cc/ee106b/sp17/class/ee106b-aam/ee106b-labs/src/ee106b_lab2/data/objects/spray.obj'
BAR_CLAMP_MESH_FILENAME = '/home/cc/ee106b/sp17/class/ee106b-aam/ee106b-labs/src/ee106b_lab2/data/objects/bar_clamp.obj'
MOUNT2_CLAMP_MESH_FILENAME = '/home/cc/ee106b/sp17/class/ee106b-aam/ee106b-labs/src/ee106b_lab2/data/objects/clamp2.obj'


def contacts_to_baxter_hand_pose(contact1, contact2):
    c1 = np.array(contact1)
    c2 = np.array(contact2)

    # compute gripper center and axis
    center = 0.5 * (c1 + c2)
    y_axis = c2 - c1
    #y_axis = np.array([0, -1, 0])
    y_axis = y_axis / np.linalg.norm(y_axis)
    z_axis = np.array([y_axis[1], -y_axis[0], 0])
    z_axis = z_axis / np.linalg.norm(z_axis)
    x_axis = np.cross(y_axis, z_axis)
    print z_axis
    print x_axis
    # convert to hand pose
    R_obj_gripper = np.array([x_axis, y_axis, z_axis]).T
    t_obj_gripper = center
    return RigidTransform(rotation=R_obj_gripper, translation=t_obj_gripper, from_frame='gripper', to_frame='obj')


def check_force_closure(c1, c2, n1, n2, mu=0.5):
    # Find segment between contacts
    line_vec = c2 - c1
    # Normalize vectors
    u_line_vec = line_vec/np.linalg.norm(line_vec)
    u_n1 = n1/np.linalg.norm(n1)
    u_n2 = n2/np.linalg.norm(n2)
    # Check to see if line segment is in friction cone
    tan = np.arctan(mu)
    if np.arccos(-np.dot(u_n1, u_line_vec)) <= tan and np.arccos(np.dot(u_n2, u_line_vec)) <= tan:
        return True
    return False

def move_to_point(position, orientation, arm, parent_frame):
    goal = PoseStamped()
    goal.header.frame_id = parent_frame
    print "Moving to:"
    print(position)
    print(orientation)
    #x, y, and z position
    goal.pose.position.x =  position[0]
    goal.pose.position.y =  position[1]
    goal.pose.position.z =  position[2]
    
    #Orientation as a quaternion
    goal.pose.orientation.x = orientation[0] 
    goal.pose.orientation.y = orientation[1]
    goal.pose.orientation.z = orientation[2]
    goal.pose.orientation.w = orientation[3]

    #Set the goal state to the pose you just defined
    arm.set_pose_target(goal)

    #Set the start state for the left arm
    arm.set_start_state_to_current_state()

    #Plan a path
    plan = arm.plan()

    #Execute the plan
    raw_input('Press <Enter> to move the right gripper to goal')
    arm.execute(plan)

def move_to_point_cartesian(position, orientation, arm, parent_frame):
    goal = Pose()
    print "Moving by cartesian path to:"
    print(position)
    print(orientation)
    #x, y, and z position
    goal.position.x =  position[0]
    goal.position.y =  position[1]
    goal.position.z =  position[2]
    
    #Orientation as a quaternion
    goal.orientation.x = orientation[0] 
    goal.orientation.y = orientation[1]
    goal.orientation.z = orientation[2]
    goal.orientation.w = orientation[3]

    #Set the goal state to the pose you just defined
    arm.set_pose_target(goal)

    #Set the start state for the left arm
    arm.set_start_state_to_current_state()

    #Plan a path
    plan = arm.plan()

    (plan, fraction) = arm.compute_cartesian_path(
                       [goal],   # waypoints to follow with end 
                       0.01,        # eef_step
                       0.0) 

    #Execute the plan
    raw_input('Press <Enter> to move the right gripper to goal')
    arm.execute(plan)

if __name__ == '__main__':
    rospy.init_node('lab2')

    # Set up MoveIt
    robot = moveit_commander.RobotCommander()
    scene = moveit_commander.PlanningSceneInterface()
    right_arm = moveit_commander.MoveGroupCommander('right_arm')
    right_arm.set_pose_reference_frame('spray')
    right_arm.set_planner_id('RRTConnectkConfigDefault')
    right_arm.set_planning_time(2)
    # Set up gripper
    right_gripper = baxter_gripper.Gripper('right')
    right_gripper.calibrate()

    # Read File
    of = ObjFile(BAR_CLAMP_MESH_FILENAME)
    mesh = of.read()

    vertices = mesh.vertices
    triangles = mesh.triangles
    normals = mesh.normals

    num_vertices = len(vertices)
    num_triangles = len(triangles)
    num_normals = len(normals)
    print ' '
    print 'Object Loaded:'
    print 'Num vertices:', num_vertices
    print 'Num triangles:', num_triangles
    print 'Num normals:', num_normals
    print ' '

    # 1. Generate candidate pairs of contact points and 2. Check for force closure

    num_points = 3 # total number of points we want to find
    num_points_found = 0
    max_dist = .04
    force_closure_contacts = []
    while (num_points_found < num_points):
        rand_num1, rand_num2 = np.random.randint(num_vertices), np.random.randint(num_vertices)
        c1, n1 = np.array(vertices[rand_num1]), np.array(normals[rand_num1])
        c2, n2 = np.array(vertices[rand_num2]), np.array(normals[rand_num2])
        if check_force_closure(c1, c2, n1, n2) and np.linalg.norm(c1 - c2) < max_dist:
            force_closure_contacts.append((c1,c2))
            num_points_found += 1

    print num_points, ' force closure grips found with maximum dist: ', max_dist
    # 3. Convert each grasp to a hand pose
    #pose_msg = T_obj_gripper.pose_msg

    # 4. Execute on the actual robot
    for contacts in force_closure_contacts:
        # 3d visualization
        vis.figure()
        vis.mesh(mesh)
        vis.points(Point(contacts[0], frame='test'))
        vis.points(Point(contacts[1], frame='test'))
        #vis.pose(T_obj_gripper, alpha=0.05)
        vis.show()

        T_obj_gripper = contacts_to_baxter_hand_pose(contacts[0], contacts[1])
        move_to_point(T_obj_gripper.translation+np.array([0,0,0.1]), T_obj_gripper.quaternion, right_arm, 'bar_clamp')

        move_to_point_cartesian(T_obj_gripper.translation, T_obj_gripper.quaternion, right_arm, 'bar_clamp')

        # Grip
        raw_input('Press enter to grip')
        print('Closing...')
        right_gripper.close(block=True)

        move_to_point_cartesian(T_obj_gripper.translation+np.array([0,0,.1]), T_obj_gripper.quaternion, right_arm, 'bar_clamp')

        #Open the left gripper
        print('Opening...')
        right_gripper.open(block=True)
        rospy.sleep(1.0)
        print('Done!')
