#!/usr/bin/env python
"""
Starter script for EE106B grasp planning lab
Author: Jeff Mahler
"""
import warnings
warnings.filterwarnings("ignore") 
import numpy as np

from core import RigidTransform, Point
from meshpy import ObjFile
from visualization import Visualizer3D as vis

import rospy
import moveit_commander
from moveit_msgs.msg import MoveGroupAction, MoveGroupGoal, MoveGroupFeedback, MoveGroupResult, JointConstraint, OrientationConstraint, Constraints
from geometry_msgs.msg import PoseStamped, Pose
from baxter_interface import gripper as baxter_gripper
import actionlib

import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning) 

SPRAY_BOTTLE_MESH_FILENAME = '/home/cc/ee106b/sp17/class/ee106b-aam/ee106b-labs/src/ee106b_lab2/data/objects/spray.obj'
BAR_CLAMP_MESH_FILENAME = '/home/cc/ee106b/sp17/class/ee106b-aam/ee106b-labs/src/ee106b_lab2/data/objects/bar_clamp.obj'
MOUNT2_CLAMP_MESH_FILENAME = '/home/cc/ee106b/sp17/class/ee106b-aam/ee106b-labs/src/ee106b_lab2/data/objects/clamp2.obj'


if __name__ == '__main__':
    rospy.init_node('lab2')

    # Read File
    of = ObjFile(SPRAY_BOTTLE_MESH_FILENAME)
    mesh = of.read()

    vertices = mesh.vertices
    triangles = mesh.triangles
    normals = mesh.normals

    # 4. Execute on the actual robot
    while True:
        if raw_input('Finished? (y)') == 'y':
            break
        if raw_input('Redo? (y) ') != 'y':
            c1 = raw_input('First contact index: ')
            c2 = raw_input('Second contact index: ')
            c1 = np.array(vertices[int(c1)])
            c2 = np.array(vertices[int(c2)])
            print('offset')
            x = raw_input()
            y = raw_input()

        #3d visualization
        vis.figure()
        vis.mesh(mesh)
        vis.points(Point(c1, frame='test'))
        vis.points(Point(c2, frame='test'))
        #vis.pose(T_obj_gripper, alpha=0.05)
        vis.show()


