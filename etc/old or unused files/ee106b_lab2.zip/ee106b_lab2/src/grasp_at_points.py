#!/usr/bin/env python
"""
Starter script for EE106B grasp planning lab
Author: Jeff Mahler
"""
import warnings
warnings.filterwarnings("ignore") 
import numpy as np

from core import RigidTransform, Point
from meshpy import ObjFile
from visualization import Visualizer3D as vis

import rospy
import moveit_commander
from moveit_msgs.msg import MoveGroupAction, MoveGroupGoal, MoveGroupFeedback, MoveGroupResult, JointConstraint, OrientationConstraint, Constraints
from geometry_msgs.msg import PoseStamped, Pose
from baxter_interface import gripper as baxter_gripper
import actionlib

import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning) 

SPRAY_BOTTLE_MESH_FILENAME = '/home/cc/ee106b/sp17/class/ee106b-aam/ee106b-labs/src/ee106b_lab2/data/objects/spray.obj'
BAR_CLAMP_MESH_FILENAME = '/home/cc/ee106b/sp17/class/ee106b-aam/ee106b-labs/src/ee106b_lab2/data/objects/bar_clamp.obj'
MOUNT2_CLAMP_MESH_FILENAME = '/home/cc/ee106b/sp17/class/ee106b-aam/ee106b-labs/src/ee106b_lab2/data/objects/mount2.obj'


def contacts_to_baxter_hand_pose(contact1, contact2):
    #c1 = np.array(contact1)
    #c2 = np.array(contact2)

    # compute gripper center and axis
    center = 0.5 * (c1 + c2)
    y_axis = abs(c2 - c1)
    #y_axis = np.array([0, -1, 0])
    y_axis = y_axis / np.linalg.norm(y_axis)
    z_axis = np.array([y_axis[1], -y_axis[0], 0])
    #z_axis = np.array([0, 0, 1])
    z_axis = z_axis / np.linalg.norm(z_axis)
    #y_axis = y_axis - np.dot(y_axis,z_axis)*z_axis
    y_axis = y_axis / np.linalg.norm(y_axis)
    x_axis = np.cross(y_axis, z_axis)

    # convert to hand pose
    R_obj_gripper = np.array([x_axis, y_axis, z_axis]).T
    t_obj_gripper = center
    return RigidTransform(rotation=R_obj_gripper, 
                          translation=t_obj_gripper,
                          from_frame='gripper',
                          to_frame='obj')

def move_to_point(position, orientation, arm, parent_frame):
    goal = PoseStamped()
    goal.header.frame_id = parent_frame
    print "Moving to:"
    print(position)
    print(orientation)
    #x, y, and z position
    goal.pose.position.x =  position[0]
    goal.pose.position.y =  position[1]
    goal.pose.position.z =  position[2]
    
    #Orientation as a quaternion
    goal.pose.orientation.x = orientation[0] 
    goal.pose.orientation.y = orientation[1]
    goal.pose.orientation.z = orientation[2]
    goal.pose.orientation.w = orientation[3]

    #Set the goal state to the pose you just defined
    arm.set_pose_target(goal)

    #Set the start state for the left arm
    arm.set_start_state_to_current_state()

    #Plan a path
    plan = arm.plan()

    #Execute the plan
    raw_input('Press <Enter> to move the right gripper to goal')
    arm.execute(plan)

def move_to_point_cartesian(position, orientation, arm, parent_frame):
    goal = Pose()
    print "Moving by cartesian path to:"
    print(position)
    print(orientation)
    #x, y, and z position
    goal.position.x =  position[0]
    goal.position.y =  position[1]
    goal.position.z =  position[2]
    
    #Orientation as a quaternion
    goal.orientation.x = orientation[0] 
    goal.orientation.y = orientation[1]
    goal.orientation.z = orientation[2]
    goal.orientation.w = orientation[3]

    #Set the start state for the left arm
    arm.set_start_state_to_current_state()

    (plan, fraction) = arm.compute_cartesian_path(
                       [goal],   # waypoints to follow with end 
                       0.02,        # eef_step
                       0.0) 

    #Execute the plan
    raw_input('Press <Enter> to move the right gripper to goal')
    arm.execute(plan)


if __name__ == '__main__':
    rospy.init_node('lab2')

    # Set up MoveIt
    robot = moveit_commander.RobotCommander()
    scene = moveit_commander.PlanningSceneInterface()
    right_arm = moveit_commander.MoveGroupCommander('right_arm')
    right_arm.set_pose_reference_frame('mount2')
    right_arm.set_planner_id('RRTConnectkConfigDefault')
    right_arm.set_planning_time(5)
    # Set up gripper
    right_gripper = baxter_gripper.Gripper('right')
    right_gripper.calibrate()

    # Read File
    of = ObjFile(MOUNT2_CLAMP_MESH_FILENAME)
    mesh = of.read()

    vertices = mesh.vertices
    triangles = mesh.triangles
    normals = mesh.normals

    # 4. Execute on the actual robot
    while True:
        if raw_input('Finished? (y)') == 'y':
            break
        if raw_input('Redo? (y) ') != 'y':
            c1 = raw_input('First contact index: ')
            c2 = raw_input('Second contact index: ')
            c1 = np.array(vertices[int(c1)])
            c2 = np.array(vertices[int(c2)])
            print('offset')
            x = raw_input()
            y = raw_input()
            z = raw_input()

        #3d visualization
        vis.figure()
        vis.mesh(mesh)
        vis.points(Point(c1, frame='test'))
        vis.points(Point(c2, frame='test'))
        #vis.pose(T_obj_gripper, alpha=0.05)
        vis.show()

        T_obj_gripper = contacts_to_baxter_hand_pose(c1, c2)
        move_to_point(T_obj_gripper.translation+np.array([float(x),float(y),float(z)]), T_obj_gripper.quaternion, right_arm, 'mount2')

        move_to_point_cartesian(T_obj_gripper.translation+np.array([0,.03,-0.03]), T_obj_gripper.quaternion, right_arm, 'mount2')
        if raw_input('Restart? (y)') != 'y':
            # Grip
            raw_input('Press enter to grip')
            print('Closing...')
            right_gripper.close(block=True)

            move_to_point_cartesian(T_obj_gripper.translation+np.array([0,0,0.1]), T_obj_gripper.quaternion, right_arm, 'mount2')
            rospy.sleep(1.0)

            move_to_point_cartesian(T_obj_gripper.translation+np.array([0.1,.2,0.05]), T_obj_gripper.quaternion, right_arm, 'mount2')
            rospy.sleep(1.0)
            move_to_point_cartesian(T_obj_gripper.translation+np.array([0.1,.2,-.1]), T_obj_gripper.quaternion, right_arm, 'mount2')

            #Open the left gripper
            print('Opening...')
            right_gripper.open(block=True)
            rospy.sleep(1.0)
            print('Done!')
