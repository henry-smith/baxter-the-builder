#!/usr/bin/env python

'''
EE106b Lab 3
Henry Smith & Andrew Chan
'''


import rospy
from geometry_msgs.msg import Twist
import pickle
import tf
import numpy as np

TRAJECTORY_FILENAME = '../desired_trajectories/test.pickle'

def tf_to_ss(tf):
    x = tf[0][0]
    y = tf[0][1]
    theta = tf[1][3]
    return [x, y, theta]

def project_onto_angle(vec, theta):
    angle_vec = np.array([np.cos(theta), np.sin(theta)])
    return np.dot(vec,angle_vec)*(angle_vec)

class ApplyTrajectory():
    def __init__(self):
        # Inititalize
        rospy.init_node('ApplyTrajectory', anonymous=False)

        self.listener = tf.TransformListener()
        self.cmd_vel = rospy.Publisher('cmd_vel_mux/input/navi', Twist, queue_size=10)
        self.r = rospy.Rate(10)
            # tell user how to stop TurtleBot
        rospy.loginfo("To stop TurtleBot CTRL + C")

        # What function to call when you ctrl + c    
        rospy.on_shutdown(self.shutdown)

        with open(TRAJECTORY_FILENAME, 'rb') as f:
            transformations = pickle.load(f)

        print('Loaded trajectory ' + TRAJECTORY_FILENAME + ' with length ' + str(len(transformations)))

        filename = raw_input('Enter filename: ')
        start_state = tf_to_ss(self.listener.lookupTransform('/base_link', '/odom', rospy.Time(0)))
        start_state[2] = 0
        actual_traj = []
        for waypoint in transformations:
            waypoint_state = tf_to_ss(waypoint)
            print('Moving to waypoint: ' + str(waypoint_state))
            actual_traj.extend(self.goto(start_state, waypoint_state))

        print('Saving trajectory as ee106b_lab3/actua_trajectories/' + filename + '.pickle')
        with open('../actual_trajectories/' + filename + '.pickle', 'wb') as f:
            pickle.dump(actual_traj , f)

        print('Finished!')

    def goto(self, start, state, distace_thresh=0.05, theta_thresh=0.001, obst_thresh=.2):
        locations = []

        curr_state = np.array(tf_to_ss(self.listener.lookupTransform('/base_link', '/odom', rospy.Time(0)))) - np.array(start)
        dist_offset = np.array(curr_state[:2])-np.array(state[:2])
        x_offset = dist_offset[0]
        theta_offset = curr_state[2]-state[2]
        d_to_obst = np.linalg.norm(np.array([-.3, 0]) - np.array(curr_state[:2]))
        count = 0
        k_lin = .25
        k_ang = 20
        while (not rospy.is_shutdown()) and (abs(x_offset) > distace_thresh or abs(theta_offset) > theta_thresh):# and count < 50:
            print '________'
            print('curr_state:' + str(curr_state))
            print('des_state:' + str(state))
            print('x_offset:' + str(x_offset))
            print('dist_offset_norm: ' + str(np.linalg.norm(dist_offset)))
            print('theta_offset: ' + str(theta_offset))
            print('dist to obj: ' + str(d_to_obst))
            move_cmd = Twist()
            if abs(x_offset) > distace_thresh:
                # vel_control =  np.dot(dist_offset, np.array([np.cos(curr_state[2]), np.sin(curr_state[2])]))*.5
                # if vel_control > 0:
                #     move_cmd.linear.x = max(vel_control, .1)
                # else:
                    # move_cmd.linear.x = min(vel_control, -.1)
                move_cmd.linear.x = -k_lin*(state[:2][0] - curr_state[:2][0])
            if abs(theta_offset) > theta_thresh or d_to_obst < obst_thresh:
            #     if theta_offset > 0:
            #         move_cmd.angular.z = max(.01, np.exp(count)*theta_offset*.5)
            #     else:
            #         move_cmd.angular.z = min(-.01, np.exp(count)*theta_offset*.5)
                ang_vel = -k_ang*(state[2] - curr_state[2])
                if d_to_obst < obst_thresh:
                    print "ASHDASHD"
                    ang_vel += np.exp(10*d_to_obst)
                move_cmd.angular.z = ang_vel
            self.cmd_vel.publish(move_cmd)
            self.r.sleep()

            locations.append(curr_state)
            curr_state = np.array(tf_to_ss(self.listener.lookupTransform('/base_link', '/odom', rospy.Time(0)))) - np.array(start)
            d_to_obst = np.linalg.norm(np.array([-.3, 0]) - np.array(curr_state[:2]))
            dist_offset = np.array(curr_state[:2])-np.array(state[:2])
            x_offset = dist_offset[0]
            d_to_obst = abs(-1 - curr_state[0])
            theta_offset = curr_state[2]-state[2]
            count += 1
        return locations

    def shutdown(self):
        # stop turtlebot
        rospy.loginfo("Stop TurtleBot")
    # a default Twist has linear.x of 0 and angular.z of 0.  So it'll stop TurtleBot
        self.cmd_vel.publish(Twist())
    # sleep just makes sure TurtleBot receives the stop command prior to shutting down the script
        rospy.sleep(1)

 
if __name__ == '__main__':
    ApplyTrajectory()

