#!/usr/bin/env python

'''
EE106b Lab 3
Henry Smith & Andrew Chan
'''


import rospy
from geometry_msgs.msg import Twist
import pickle
import tf
import numpy as np

TRAJECTORY_FILENAME = '../desired_trajectories/line.pickle'

def tf_to_ss(tf):
    x = tf[0][0]
    y = tf[0][1]
    theta = tf[1][3]
    return [x, y, theta]

def project_onto_angle(vec, theta):
    angle_vec = np.array([np.cos(theta), np.sin(theta)])
    return np.dot(vec,angle_vec)*(angle_vec)

class ApplyTrajectory():
    def __init__(self):
        # Inititalize
        rospy.init_node('ApplyTrajectory', anonymous=False)

        self.listener = tf.TransformListener()
        self.cmd_vel = rospy.Publisher('cmd_vel_mux/input/navi', Twist, queue_size=10)
        self.r = rospy.Rate(10)
            # tell user how to stop TurtleBot
        rospy.loginfo("To stop TurtleBot CTRL + C")

        # What function to call when you ctrl + c    
        rospy.on_shutdown(self.shutdown)

        with open(TRAJECTORY_FILENAME, 'rb') as f:
            transformations = pickle.load(f)

        print('Loaded trajectory ' + TRAJECTORY_FILENAME + ' with length ' + str(len(transformations)))
        actual_traj = []
        filename = raw_input('Enter filename: ')
        start_state = tf_to_ss(self.listener.lookupTransform('/base_link', '/odom', rospy.Time(0)))
        start_state[2] = 0
        for waypoint in transformations:
            waypoint_state = tf_to_ss(waypoint)
            print('Moving to waypoint: ' + str(waypoint_state))
            actual_traj.extend(self.goto(np.array(waypoint_state)+np.array(start_state)))

        print('Saving trajectory as ee106b_lab3/actua_trajectories/' + filename + '.pickle')
        with open('../actual_trajectories/' + filename + '.pickle', 'wb') as f:
            pickle.dump(actual_traj , f)

        print('Finished!')

    def goto(self, state, distace_thresh=.3, theta_thresh=0.01):
        locations = []

        object_state = curr_state = tf_to_ss(self.listener.lookupTransform('/base_link', '/odom', rospy.Time(0)))
        object_state = np.array(object_state[:2])
        object_dist = 0
        object_state[0] -= .7
        dist_offset = np.array(curr_state[:2])-np.array(state[:2])
        x_offset = dist_offset[0]
        theta_offset = curr_state[2]-state[2]
        count = 0
        yoffset =0
        k_lin = .25
        k_ang = 40
        while (not rospy.is_shutdown()) and (abs(x_offset) > distace_thresh or abs(theta_offset) > theta_thresh) and count < 10000:
            print '________'
            print('curr_state:' + str(curr_state))
            print('des_state:' + str(state))
            print('x_offset:' + str(x_offset))
            print('dist_offset_norm: ' + str(np.linalg.norm(dist_offset)))
            print('theta_offset: ' + str(theta_offset))
            print('object_dist: ' + str(object_dist))
            print('y offset: ' + str(yoffset))
            move_cmd = Twist()

            if abs(x_offset) > distace_thresh:
                vel_control =  -k_lin*(state[:2][0] - curr_state[:2][0])
                #vel_control =  np.dot(dist_offset, np.array([np.cos(curr_state[2]), np.sin(curr_state[2])]))*1
                if vel_control > 0:
                    move_cmd.linear.x = min(.1, max(vel_control, .01))
                else:
                    move_cmd.linear.x = max(-.1, min(vel_control, -.01))

            yoffset = state[1] - curr_state[1]
            object_dist = np.linalg.norm(np.array(curr_state[:2]) - object_state)
            if abs(theta_offset) > theta_thresh or abs(yoffset) > .01 or object_dist < .4:
                ang_vel = 0
                if abs(theta_offset) > theta_thresh:
                    print('fds')
                    ang_vel -= k_ang*(state[2] - curr_state[2])
                if abs(yoffset) > .01:
                    print('sdf')
                    ang_vel+= (yoffset)*50
                if object_dist < .2:
                    print('aaa')
                    ang_vel += min(100,(100000/object_dist))
                if ang_vel > 0:
                    move_cmd.angular.z = min(1, max(.0001, ang_vel))
                else:
                    move_cmd.angular.z = max(-1, min(-.0001, ang_vel))


            print(move_cmd.angular.z)
            self.cmd_vel.publish(move_cmd)
            self.r.sleep()

            locations.append(curr_state)
            curr_state = tf_to_ss(self.listener.lookupTransform('/base_link', '/odom', rospy.Time(0)))
            dist_offset = np.array(curr_state[:2])-np.array(state[:2])
            x_offset = dist_offset[0]
            theta_offset = curr_state[2]-state[2]
            count += 1
        return locations

    def shutdown(self):
        # stop turtlebot
        rospy.loginfo("Stop TurtleBot")
    # a default Twist has linear.x of 0 and angular.z of 0.  So it'll stop TurtleBot
        self.cmd_vel.publish(Twist())
    # sleep just makes sure TurtleBot receives the stop command prior to shutting down the script
        rospy.sleep(1)

 
if __name__ == '__main__':
    ApplyTrajectory()

