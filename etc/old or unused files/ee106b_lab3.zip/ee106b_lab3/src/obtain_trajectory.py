#!/usr/bin/env python

'''
EE106b Lab 3
Henry Smith & Andrew Chan
'''


import rospy
from geometry_msgs.msg import Twist
import tf
import pickle

class ObtainTrajectory():
    def __init__(self):
        # Inititalize
        rospy.init_node('ObtainTrajectory', anonymous=False)
        listener = tf.TransformListener()
        filename = raw_input('Enter filename: ')
        transformations = []
        print('Type exit to save, press enter to continue')
        while not rospy.is_shutdown():
            if raw_input() == 'exit':
                break
            transformations.append(listener.lookupTransform('/base_link', '/odom', rospy.Time(0)))
            print('length of trajectory: ' + str(len(transformations)))

        with open('../desired_trajectories/' + filename + '.pickle', 'wb') as f:
            pickle.dump(transformations , f)
        
        print('Saved as ee106b_lab3/desired_trajectories/' + filename + '.pickle')
if __name__ == '__main__':
    ObtainTrajectory()

