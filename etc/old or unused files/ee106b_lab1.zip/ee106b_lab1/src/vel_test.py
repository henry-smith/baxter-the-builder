#!/usr/bin/env python
"""
Starter script for lab1. Demonstrates following an AR marker
Author: Jeff Mahler
"""
import copy
import rospy
import sys

import baxter_interface
import moveit_commander
from moveit_msgs.msg import OrientationConstraint, Constraints
from geometry_msgs.msg import PoseStamped
from baxter_pykdl import baxter_kinematics
from std_msgs.msg import (
    UInt16,
)
from baxter_core_msgs.msg import EndpointState
from ee106b_lab1.srv import *

import IPython
import tf
import time
import numpy as np

def main():
    #Initialize moveit_commander
    moveit_commander.roscpp_initialize(sys.argv)
    #Start a node
    rospy.init_node('moveit_node')
    kin = baxter_kinematics('right')


    #Initialize the left limb for joint velocity control
    limb = baxter_interface.Limb('left')
    angles = limb.joint_angles()
    velocities = limb.joint_velocities()

    #Command joint velocites
    num_cmd = 25
    cmd_velocities = copy.deepcopy(velocities)
    endpointInfo = rospy.ServiceProxy('endpoint_info', endpoint_service)

    print 'Commanding velocity'
    desired = np.array([0, -.1, 0, 0, 0, 0])
    curr = desired
    for i in range(num_cmd):
        jointVels = np.dot(np.array(np.linalg.pinv(kin.jacobian())), desired)
        limb.set_joint_velocities(velocityDictionary(jointVels))
        actual = twistToArray(endpointInfo().twist)
        #actual_pos = twistToArray(endpointInfo().pose)
        error = desired - actual
        curr = desired + .1*error
        time.sleep(0.1)

    desired = np.array([0, -0.1, 0, 0, 0, 0])
    curr = desired
    for i in range(num_cmd):
        jointVels = np.dot(np.array(np.linalg.pinv(kin.jacobian())), desired)
        limb.set_joint_velocities(velocityDictionary(jointVels))
        actual = twistToArray(endpointInfo().twist)
        #actual_pos = twistToArray(endpointInfo().pose)
        error = desired - actual
        curr = desired + .1*error
        #limb.set_joint_velocities(cmd_velocities)
        time.sleep(0.1)


def velocityDictionary(vels):
    velocityDictionary = {}
    velocityDictionary['left_e0'] = vels[0]
    velocityDictionary['left_e1'] = vels[1]
    velocityDictionary['left_s0'] = vels[2]
    velocityDictionary['left_s1'] = vels[3]
    velocityDictionary['left_w0'] = vels[4]
    velocityDictionary['left_w1'] = vels[5]
    velocityDictionary['left_w2'] = vels[6]
    return velocityDictionary

def twistToArray(twist):
    lin = twist.linear
    ang = twist.angular
    return np.array([lin.x, lin.y, lin.z, ang.x, ang.y, ang.z])

def printq(state):
    print(state)


if __name__ == '__main__':
    main()
