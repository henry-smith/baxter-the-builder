#!/usr/bin/env python
"""
EE106b Lab 1 
Authors: Henry Smith Andrew Chan
"""
import copy
import rospy
import sys

import baxter_interface
import moveit_commander
from moveit_msgs.msg import OrientationConstraint, Constraints
from moveit_msgs.srv import GetPositionIK, GetPositionIKRequest, GetPositionIKResponse
from geometry_msgs.msg import PoseStamped
from baxter_interface import gripper as baxter_gripper
from std_msgs.msg import (
    UInt16,
)
from ee106b_lab1.srv import *

import IPython
import tf
import time
import numpy as np

def getLinearPathWaypoints(start, end, num_points):
    waypoint_distance = (end - start)/num_points
    result = [np.copy(start)]
    for i in range(num_points):
        start += waypoint_distance
        result.append(np.copy(start))   
    return result   

def getCircularPathWaypoints(origin, radius, num_points):
    z = origin[2]
    result = []
    for i in range(num_points):
        x = origin[0] + np.cos((2*np.pi/num_points)*i)*radius
        y = origin[1] + np.sin((2*np.pi/num_points)*i)*radius
        result.append(np.array([x, y, z]))
    return result

def proceedThruWaypoints(waypoints, arm, height):
    rospy.wait_for_service('endpoint_info')
    endpointInfo = rospy.ServiceProxy('endpoint_info', endpoint_service)
    endpointLoad = rospy.ServiceProxy('endpoint_load', endpoint_load)
    for i in range(len(waypoints)):
        if i == 1:
            endpointLoad()
        goal = PoseStamped()
        goal.header.frame_id = "base"
        #x, y, and z position
        goal.pose.position.x = waypoints[i][0]
        goal.pose.position.y = waypoints[i][1]
        goal.pose.position.z = waypoints[i][2] + height
        
        #Orientation as a quaternion
        goal.pose.orientation.x = 0.0
        goal.pose.orientation.y = 1.0
        goal.pose.orientation.z = 0.0
        goal.pose.orientation.w = 0.0

        #Set the goal state to the pose you just defined
        arm.set_pose_target(goal)

        #Set the start state for the left arm
        arm.set_start_state_to_current_state()

        #Plan a path
        left_plan = arm.plan()

        #Execute the plan
        print('Next position')
        print waypoints[i]
        #raw_input('Press <Enter> to move the left arm to next position')
        arm.execute(left_plan)

        #Control
        actual_position = endpointInfo().pose.position
        print actual_position
        print waypoints[i]
        error = np.array([actual_position.x, actual_position.y, actual_position.z - height]) - waypoints[i]
        if i != len(waypoints) - 1:
            waypoints[i + 1] -= error

def main():
    #Initialize moveit_commander
    moveit_commander.roscpp_initialize(sys.argv)
    endpointSave = rospy.ServiceProxy('endpoint_save', endpoint_save)
    #Start a node
    rospy.init_node('moveit_node')

    #Start tf node
    listener = tf.TransformListener()
    from_frame = 'base'
    to_frames = ['ar_marker_4', 'ar_marker_3', 'ar_marker_1', 'ar_marker_6']
    time.sleep(1)
    if not listener.frameExists(from_frame):
        if not listener.frameExists(to_frame):
            print 'Frames not found'
            exit(0)
    for to_frame in to_frames:
        if not listener.frameExists(to_frame):
            print 'Frames not found'
            print to_frame
            exit(0)

    #Initialize the moveit commander for the left arm
    print 'Setting up planning'
    robot = moveit_commander.RobotCommander()
    scene = moveit_commander.PlanningSceneInterface()
    left_arm = moveit_commander.MoveGroupCommander('left_arm')
    left_arm.set_planner_id('RRTConnectkConfigDefault')
    left_arm.set_planning_time(10)

    # #Part a
    print('getting pose of AR tag')
    t = listener.getLatestCommonTime(from_frame, to_frames[0])
    position, quaternion = listener.lookupTransform(from_frame, to_frames[0], t)
    print('finding waypoints')
    linear_path = getLinearPathWaypoints(np.array(list(position)) - np.array([.2, 0.2, 0]), np.array(list(position)), 5)
    proceedThruWaypoints(linear_path, left_arm, .15)
    endpointSave('a_workspace.pickle')

    # #Part b
    print('finding circular waypoints')
    circular_path = getCircularPathWaypoints(np.array(list(position)), 0.1, 16)
    proceedThruWaypoints(circular_path, left_arm, .2)
    # proceedThruWaypoints(circular_path, left_arm, .2)
    # proceedThruWaypoints(circular_path, left_arm, .2)
    endpointSave('b_default.pickle')

    # #Part C
    # #Get poses
    waypoints = []
    heights = [.15, .25, .15, .25]
    t = listener.getLatestCommonTime(from_frame, to_frames[3])
    lastPosition, _ = listener.lookupTransform(from_frame, to_frames[3], t)
    lastPosition = np.array(list(lastPosition)) + np.array([0, 0, heights[3]])
    for i, to_frame in enumerate(to_frames):
        t = listener.getLatestCommonTime(from_frame, to_frame)
        position, quaternion = listener.lookupTransform(from_frame, to_frame, t)
        nextPosition = np.array(list(position)) + np.array([0, 0, heights[i]])
        waypoints.extend(getLinearPathWaypoints(lastPosition, nextPosition, 5))
        lastPosition = nextPosition
    print waypoints
    proceedThruWaypoints(waypoints, left_arm, 0)
    # proceedThruWaypoints(waypoints, left_arm, 0)
    # proceedThruWaypoints(waypoints, left_arm, 0)
    endpointSave('c_workspace.pickle')


if __name__ == '__main__':
    main()