#!/usr/bin/env python
"""
EE106b Lab 1 
Authors: Henry Smith Andrew Chan
"""
import copy
import rospy
import sys

import baxter_interface
import moveit_commander
from baxter_pykdl import baxter_kinematics
from moveit_msgs.msg import OrientationConstraint, Constraints
from moveit_msgs.srv import GetPositionIK, GetPositionIKRequest, GetPositionIKResponse
from geometry_msgs.msg import PoseStamped
from baxter_interface import gripper as baxter_gripper
from std_msgs.msg import (
    UInt16,
)
from ee106b_lab1.srv import *

import IPython
import tf
import time
import numpy as np

def linearPath(start, end, velocity, timeStep):
    pathVector = end - start
    totalTime = np.linalg.norm(pathVector)/velocity
    totalSteps = int(totalTime/timeStep)
    expectedVelocity = (pathVector/np.linalg.norm(pathVector))*velocity
    expectedPositions = [np.copy(start)]
    expectedVelocities = [np.copy(expectedVelocity)]
    stepDelta = pathVector/totalSteps
    for i in range(totalSteps):
        start += stepDelta
        expectedPositions.append(np.copy(start))
        expectedVelocities.append(np.copy(expectedVelocity))
    return (expectedVelocities, expectedPositions, timeStep)

def circularPath(center, radius, velocity, timeStep):
    expectedPositions = []
    expectedVelocities = []
    totalTime = np.pi*2*radius/velocity
    totalSteps = int(totalTime/timeStep)
    z = center[2]
    for i in range(totalSteps):
        x = center[0] + np.cos((2*np.pi/totalSteps)*i)*radius
        y = center[1] + np.sin((2*np.pi/totalSteps)*i)*radius
        expectedPositions.append(np.array([x, y, z]))
        vel_dir = np.array([y, x, 0])
        expectedVelocities.append((vel_dir/np.linalg.norm(vel_dir))*velocity)
    return (expectedVelocities, expectedPositions, timeStep)

def executePath(path, limb):
    rospy.wait_for_service('endpoint_info')
    kin = baxter_kinematics('right')
    Kp, Kd = .005, .01
    endpointInfo = rospy.ServiceProxy('endpoint_info', endpoint_service)
    endpointLoad = rospy.ServiceProxy('endpoint_load', endpoint_load)
    expectedVelocity = path[0]
    expectedAngularVelocity = np.array([0, 0, 0])
    expectedPositions = path[1]
    expectedOrientation = [0, 1, 0, 0]
    timeStep = path[2]
    curr = np.append(expectedVelocity[0], expectedAngularVelocity)
    endpointLoad()
    for i in range(len(expectedPositions)):
        jointVels = np.dot(np.array(kin.jacobian_pseudo_inverse()), curr)
        limb.set_joint_velocities(velocityDictionary(jointVels))
        time.sleep(0.1)
        #Control
        actual_position = endpointInfo().pose.position
        act_pos = [actual_position.x, actual_position.y, actual_position.z]
        actual_orientation = endpointInfo().pose.orientation
        actual_twist = twistToArray(endpointInfo().twist)
        actual_joint_angles = limb.joint_angles()

        e_twist = np.array(actual_twist) - np.append(expectedVelocity[i], expectedAngularVelocity)
        ik = kin.inverse_kinematics(position=expectedPositions[i], orientation=expectedOrientation)
        if ik is None:
            e_workspace = np.array([0,0,0,0,0,0])
        else:
            e_joints = np.array(ik)- np.array(velocityDictionaryToArray(actual_joint_angles))
            e_workspace = np.dot(kin.jacobian(),e_joints)
        curr = np.append(expectedVelocity[i], expectedAngularVelocity) - Kd*e_twist - Kp*e_workspace
        curr = np.transpose(curr)

def velocityDictionary(vels):
    velocityDictionary = {}
    velocityDictionary['left_e0'] = vels[0]
    velocityDictionary['left_e1'] = vels[1]
    velocityDictionary['left_s0'] = vels[2]
    velocityDictionary['left_s1'] = vels[3]
    velocityDictionary['left_w0'] = vels[4]
    velocityDictionary['left_w1'] = vels[5]
    velocityDictionary['left_w2'] = vels[6]
    return velocityDictionary

def velocityDictionaryToArray(velocityDictionary):
    vels = [0] * 7
    vels[0] = velocityDictionary['left_e0']
    vels[1] = velocityDictionary['left_e1']
    vels[2] = velocityDictionary['left_s0']
    vels[3] = velocityDictionary['left_s1']
    vels[4] = velocityDictionary['left_w0']
    vels[5] = velocityDictionary['left_w1']
    vels[6] = velocityDictionary['left_w2']
    return vels

def twistToArray(twist):
    lin = twist.linear
    ang = twist.angular
    return np.array([lin.x, lin.y, lin.z, ang.x, ang.y, ang.z])

def main():
    #Initialize moveit_commander
    moveit_commander.roscpp_initialize(sys.argv)
    endpointSave = rospy.ServiceProxy('endpoint_save', endpoint_save)
    endpointInfo = rospy.ServiceProxy('endpoint_info', endpoint_service)

    #Start a node
    rospy.init_node('moveit_node')

    #Start tf node
    listener = tf.TransformListener()
    from_frame = 'base'
    to_frames = ['ar_marker_4']#, 'ar_marker_3', 'ar_marker_1', 'ar_marker_6']
    time.sleep(1)
    if not listener.frameExists(from_frame):
        if not listener.frameExists(to_frame):
            print 'Frames not found'
            exit(0)
    for to_frame in to_frames:
        if not listener.frameExists(to_frame):
            print 'Frames not found'
            print to_frame
            exit(0)

    limb = baxter_interface.Limb('left')

    #Part a
    print('getting pose of AR tag')
    t = listener.getLatestCommonTime(from_frame, to_frames[0])
    position, quaternion = listener.lookupTransform(from_frame, to_frames[0], t)
    actual_position = endpointInfo().pose.position
    act_pos = np.array([actual_position.x, actual_position.y, actual_position.z])
    print('finding path')
    position = np.array(list(position)) + np.array([0, 0, .1])
    linear_path = linearPath(act_pos, position - np.array([.1, 0.1, 0]), .1, .1)
    executePath(linear_path, limb)
    linear_path = linearPath(position - np.array([.1, 0.1, 0]), np.array(list(position)), .1, .1)
    executePath(linear_path, limb)
    endpointSave('a_velocity.pkl')

    # #Part b
    # print('finding circular waypoints')
    # circular_path = circularPath(position, 0.1, 0.1, .1)
    # executePath(circular_path, limb)
    # endpointSave('b_velocity.pkl')

    # #Part C
    # #Get poses
    # waypoints = []
    # heights = [.2, .25, .2, .25]
    # t = listener.getLatestCommonTime(from_frame, to_frames[3])
    # lastPosition, _ = listener.lookupTransform(from_frame, to_frames[3], t)
    # moveToTag(to_frames[0], np.array([0, 0, heights[3]]))
    # lastPosition = np.array(list(lastPosition)) + np.array([0, 0, heights[3]])
    # for i, to_frame in enumerate(to_frames):
    #     t = listener.getLatestCommonTime(from_frame, to_frame)
    #     position, quaternion = listener.lookupTransform(from_frame, to_frame, t)
    #     nextPosition = np.array(list(position)) + np.array([0, 0, heights[i]])
    #     linear_path = linearPath(lastPosition, nextPosition, .1, .1)
    #     executePath(linear_path, limb)
    #     lastPosition = nextPosition
    # print waypoints
    # proceedThruWaypoints(waypoints, left_arm, 0)
    # endpointSave('c_velocity.pkl')


if __name__ == '__main__':
    main()