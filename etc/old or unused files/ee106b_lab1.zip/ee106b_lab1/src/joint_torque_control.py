#!/usr/bin/env python
"""
Starter script for lab1. Demonstrates following an AR marker
Author: Jeff Mahler
"""
import copy
import rospy
import sys

import baxter_interface
import moveit_commander
from moveit_msgs.msg import OrientationConstraint, Constraints
from geometry_msgs.msg import PoseStamped

import IPython
import tf
import time

def main():
    #Initialize moveit_commander
    moveit_commander.roscpp_initialize(sys.argv)

    #Start a node
    rospy.init_node('moveit_node')

    #Start tf node
    listener = tf.TransformListener()
    from_frame = 'base'
    to_frames = ['ar_marker_4', 'ar_marker_3', 'ar_marker_1', 'ar_marker_6']
    time.sleep(1)
    if not listener.frameExists(from_frame):
        if not listener.frameExists(to_frame):
            print 'Frames not found'
            exit(0)
    for to_frame in to_frames:
        if not listener.frameExists(to_frame):
            print 'Frames not found'
            print to_frame
            exit(0)

    #Initialize the left limb for joint velocity control
    limb = baxter_interface.Limb('left')
    angles = limb.joint_angles()
    velocities = limb.joint_velocities()
    
    cmd_torques['left_e1'] = 0.1
    for i in range(num_cmd):
        limb.set_joint_torques(cmd_torques)
        time.sleep(0.1)
    time.sleep(0.5)

    cmd_torques['left_e1'] = -0.1
    for i in range(num_cmd):
        limb.set_joint_torques(cmd_torques)
        time.sleep(0.1)
    time.sleep(0.5)

if __name__ == '__main__':
    main()
