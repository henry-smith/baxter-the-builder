#!/usr/bin/env python
"""
EE106b Lab 1 
Authors: Henry Smith Andrew Chan
"""
import copy
import rospy
import sys

import baxter_interface
import moveit_commander
from moveit_msgs.msg import OrientationConstraint, Constraints
from moveit_msgs.srv import GetPositionIK, GetPositionIKRequest, GetPositionIKResponse
from geometry_msgs.msg import PoseStamped
from baxter_interface import gripper as baxter_gripper
from baxter_pykdl import baxter_kinematics
from std_msgs.msg import (
    UInt16,
)
from ee106b_lab1.srv import *

import IPython
import tf
import time
import numpy as np

def main():
    #Initialize moveit_commander
    moveit_commander.roscpp_initialize(sys.argv)

    #Start a node
    rospy.init_node('moveit_node')

    #Start tf node
    listener = tf.TransformListener()
    from_frame = 'base'
    to_frame = 'ar_marker_1'
    time.sleep(1)
    if not listener.frameExists(from_frame) or not listener.frameExists(to_frame):
        if not listener.frameExists(to_frame):
            print 'Frames not found'
            exit(0)

    print 'Setting up planning'
    robot = moveit_commander.RobotCommander()
    scene = moveit_commander.PlanningSceneInterface()
    left_arm = moveit_commander.MoveGroupCommander('left_arm')
    left_arm.set_planner_id('RRTConnectkConfigDefault')
    left_arm.set_planning_time(10)

    while True:
        t = listener.getLatestCommonTime(from_frame, to_frame)
        position, quaternion = listener.lookupTransform(from_frame, to_frame, t)
        goal_1 = PoseStamped()
        goal_1.header.frame_id = "base"

        #x, y, and z position
        goal_1.pose.position.x = position[0]
        goal_1.pose.position.y = position[1]
        goal_1.pose.position.z = position[2] + 0.2
        
        #Orientation as a quaternion
        goal_1.pose.orientation.x = 0.0
        goal_1.pose.orientation.y = 1.0
        goal_1.pose.orientation.z = 0.0
        goal_1.pose.orientation.w = 0.0

        #Set the goal state to the pose you just defined
        left_arm.set_pose_target(goal_1)

        #Set the start state for the left arm
        left_arm.set_start_state_to_current_state()

        #Plan a path
        left_plan = left_arm.plan()

        left_arm.execute(left_plan)
        time.sleep(1)

if __name__ == '__main__':
    main()