#!/usr/bin/env python
"""
EE106b Lab 1 
Authors: Henry Smith Andrew Chan
"""
import copy
import rospy
import sys

import baxter_interface
import moveit_commander
from moveit_msgs.msg import OrientationConstraint, Constraints
from moveit_msgs.srv import GetPositionIK, GetPositionIKRequest, GetPositionIKResponse
from geometry_msgs.msg import PoseStamped
from baxter_interface import gripper as baxter_gripper
from std_msgs.msg import (
    UInt16,
)

import IPython
import tf
import time
import numpy as np

def main():
    #Initialize moveit_commander
    moveit_commander.roscpp_initialize(sys.argv)

    #Start a node
    rospy.init_node('moveit_node')

    #Start tf node
    listener = tf.TransformListener()
    from_frame = 'base'
    to_frame = 'ar_marker_0'
    time.sleep(1)
    if not listener.frameExists(from_frame) or not listener.frameExists(to_frame):
        print 'Frames not found'
        print 'Did you place AR marker 0 within view of the baxter left hand camera?'
        exit(0)

    #Initialize the left limb for joint velocity control
    limb = baxter_interface.Limb('left')
    angles = limb.joint_angles()
    velocities = limb.joint_velocities()

    #Initialize the moveit commander for the left arm
    print 'Setting up planning'
    robot = moveit_commander.RobotCommander()
    scene = moveit_commander.PlanningSceneInterface()
    left_arm = moveit_commander.MoveGroupCommander('left_arm')
    left_arm.set_planner_id('RRTConnectkConfigDefault')
    left_arm.set_planning_time(10)

    #Get pose
    t = listener.getLatestCommonTime(from_frame, to_frame)
    position, quaternion = listener.lookupTransform(from_frame, to_frame, t)

    #Wait for the IK service to become available
    rospy.wait_for_service('compute_ik')

    #Create the function used to call the service
    compute_ik = rospy.ServiceProxy('compute_ik', GetPositionIK)

    #Use IK to compute final joint angles
    #Construct the request
    request = GetPositionIKRequest()
    request.ik_request.group_name = "left_arm"
    request.ik_request.attempts = 20
    request.ik_request.pose_stamped.header.frame_id = "base"

    #Set the desired orientation for the end effector
    request.ik_request.pose_stamped.pose.position.x = position[0]
    request.ik_request.pose_stamped.pose.position.y = position[1]
    request.ik_request.pose_stamped.pose.position.z = position[2] + 0.1
    request.ik_request.pose_stamped.pose.orientation.x = 0.0
    request.ik_request.pose_stamped.pose.orientation.y = 1.0
    request.ik_request.pose_stamped.pose.orientation.z = 0.0
    request.ik_request.pose_stamped.pose.orientation.w = 0.0

    try:
        #Send the request to the service
        response = compute_ik(request)

        #Print the response
        print('repsonse:')
        print('________')
        print(response)
        ik_angles = response.solution.joint_state.position[1:9]
        desired_angles = createDictionary(ik_angles)
        actual_angles = angles
    except rospy.ServiceException, e:
        print("Service call failed: %s"%e)
    print 'desired angles'
    #Controller part:
    num_cmds = 25
    threshold = 0.05
    print desired_angles
    for curr_joint in desired_angles.keys():
        print 'curr joint'
        print curr_joint
        print 'diff'
        actual = actual_angles[curr_joint]
        desired = desired_angles[curr_joint]
        print abs(actual - desired)
        while (abs(actual - desired) > threshold):
            limb.set_joint_positions({curr_joint: desired})
            actual = limb.joint_angle(curr_joint)
            time.sleep(0.1)
        time.sleep(0.5)


def createDictionary(vals):
    dictionary = {}
    dictionary['left_e0'] = vals[0]
    dictionary['left_e1'] = vals[1]
    dictionary['left_s0'] = vals[2]
    dictionary['left_s1'] = vals[3]
    dictionary['left_w0'] = vals[4]
    dictionary['left_w1'] = vals[5]
    dictionary['left_w2'] = vals[6]
    return dictionary

if __name__ == '__main__':
    main()