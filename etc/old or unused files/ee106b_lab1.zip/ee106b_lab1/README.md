# ee106b_lab1
Starter ROS package for EE106B Lab1: Trajectory Tracking with Baxter
